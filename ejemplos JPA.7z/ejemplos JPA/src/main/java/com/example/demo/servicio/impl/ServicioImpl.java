package com.example.demo.servicio.impl;

import com.example.demo.dto.CourseDto;
import com.example.demo.dto.ManyToManyRequest;
import com.example.demo.dto.OneToOneRequest;
import com.example.demo.dto.StudentDto;
import com.example.demo.entidad.Address;
import com.example.demo.entidad.Course;
import com.example.demo.entidad.Student;
import com.example.demo.entidad.User;
import com.example.demo.repositorio.AddressRepository;
import com.example.demo.repositorio.CourseRepository;
import com.example.demo.repositorio.StudentRepository;
import com.example.demo.repositorio.UserRepository;
import com.example.demo.servicio.Servicio;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static java.time.temporal.TemporalAdjusters.lastDayOfMonth;

@Service
@Slf4j
public class ServicioImpl implements Servicio {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public void oneToOne(OneToOneRequest request) {

        try { //el try es para logear el error en este caso

            //revisamos que el id este null, si el front manda id sera un update
            //pero que pasa si solo uno trae id y el otro no? seria insert a uno y update a otro
            //no voy a hacer esos casos para este ejemplo.
            //personalmente prefiero hacer endpoints separados, especialmente si son tablas con relacion
            //si es solo una tabla es mas facil hacerlo en un endpoint sin tener que validar muchos casos
            if (request.getUserDto().getId() == null || request.getAddressDto().getId() == null) {
                log.info("insert one to one");

                if (request.getUserDto().getId() == null && request.getAddressDto().getId() == null) {
                    //insertar User Y Address
                    log.info("insert one to one user AND address");
                    User userInsert = User.builder()
                            .descripcion(request.getUserDto().getDescripcion())
                            .build();
                    Address addressInsert = Address.builder()
                            .descripcion(request.getAddressDto().getDescripcion())
                            .build();
                    userInsert.setAddress(addressInsert);
                    addressInsert.setUser(userInsert);

                    User savedUser = userRepository.save(userInsert);//opcion 1, guardar desde user
                    log.info("saved user: {}", savedUser);
                    log.info("saved address: {}", savedUser.getAddress());

                    //Address savedAddress = addressRepository.save(addressInsert);//opcion 2, guardar desde address
                    //log.info("saved user: {}", savedAddress.getUser());
                    //log.info("saved address: {}", savedAddress);

                } else if (request.getUserDto().getId() == null) {
                    //insertar SOLO user
                    log.info("insert one to one ONLY user");
                    User userInsert = User.builder()
                            .descripcion(request.getUserDto().getDescripcion())
                            .build();
                    User savedUser = userRepository.save(userInsert);
                    log.info("saved user: {}", savedUser);
                } else if (request.getAddressDto().getId() == null) {
                    //insertar SOLO address
                    log.info("insert one to one ONLY address");
                    Address addressInsert = Address.builder()
                            .descripcion(request.getAddressDto().getDescripcion())
                            .build();
                    Address savedAddress = addressRepository.save(addressInsert);
                    log.info("saved address: {}", savedAddress);
                }
            } else {
                log.info("update ono to one");

                //Aqui recomiendo hacer otro check que no hare en este ejemplo, que es consultar en BD
                // que el id que recibe existe, ya que si no existe el update dara error.
                //update: inesperadamente para mi, cuando probe esto, hizo selects antes de insertar, asi que quizas no sea necesario
                //update 2: probe no tener nada insertado pero enviar los id, hizo los select, vio que no existian
                // y genero insert en vez de update, por lo que mucha de esta validacion no es necesaria
                if (request.getUserDto().getId() != null && request.getAddressDto().getId() != null) {
                    //actualizar User Y Address
                    log.info("update one to one user AND address");
                    User userUpdate = User.builder()
                            .id(request.getUserDto().getId())
                            .descripcion(request.getUserDto().getDescripcion())
                            .build();
                    Address addressUpdate = Address.builder()
                            .id(request.getAddressDto().getId())
                            .descripcion(request.getAddressDto().getDescripcion())
                            .build();
                    userUpdate.setAddress(addressUpdate);
                    addressUpdate.setUser(userUpdate);

                    User updatedUser = userRepository.save(userUpdate);//opcion 1, guardar desde user
                    log.info("updated user: {}", updatedUser);
                    log.info("updated address: {}", updatedUser.getAddress());

                    //Address updatedAddress = addressRepository.save(addressUpdate);//opcion 2, guardar desde address
                    //log.info("updated user: {}", updatedAddress.getUser());
                    //log.info("updated address: {}", updatedAddress);

                } else if (request.getUserDto().getId() == null) {
                    //actualizar SOLO user
                    log.info("update one to one ONLY user");
                    User userUpdate = User.builder()
                            .id(request.getUserDto().getId())
                            .descripcion(request.getUserDto().getDescripcion())
                            .build();
                    User updatedUser = userRepository.save(userUpdate);
                    log.info("updated user: {}", updatedUser);
                } else if (request.getAddressDto().getId() == null) {
                    //actualizar SOLO address
                    log.info("update one to one ONLY address");
                    Address addressUpdate = Address.builder()
                            .id(request.getAddressDto().getId())
                            .descripcion(request.getAddressDto().getDescripcion())
                            .build();
                    Address updatedAddress = addressRepository.save(addressUpdate);
                    log.info("updated address: {}", updatedAddress);
                }

            }
        } catch (Exception e) {
            log.error("error", e);
        }

    }

    @Override
    public void oneToOne2(OneToOneRequest request) {
        //basado en lo que descubri anteriormente, que JPA hace un select cuando le enviamos a guardar algo con id
        //para identificar si es un insert o un update, en teoria podemos validar menos.

        ZoneId zoneIdChile = ZoneId.of("Chile/Continental");
        //tengo mes y año
        int month = 01;
        int year = 2024;
        LocalDate monthYear = LocalDate.of(year,month,1);
        log.info("monthYear {}",monthYear.format(DateTimeFormatter.ofPattern("yyyy-MM")));
        LocalDate monthYearMinusOneMonth = monthYear.minusMonths(1L);
        log.info("monthYearMinusOneMonth {}",monthYearMinusOneMonth.format(DateTimeFormatter.ofPattern("yyyy-MM")));
        log.info("solo mes de monthYearMinusOneMonth {}",Integer.valueOf(monthYearMinusOneMonth.format(DateTimeFormatter.ofPattern("MM"))));
        log.info("solo año de monthYearMinusOneMonth {}",Integer.valueOf(monthYearMinusOneMonth.format(DateTimeFormatter.ofPattern("yyyy"))));

        Date testingFecha = new Date();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm"); //01/01/24 12:45
        log.info("---------- {}",formatter.format(testingFecha));

        /*
        //generacion fechas, periodo (año-(mes-1))
        LocalDate localDate = LocalDate.now(zoneIdChile).minusMonths(1).with(lastDayOfMonth());
        // esta es para un texto que indica que las cotizaciones son del mes anterior al mes de la cartola
        LocalDate localDate2 = LocalDate.now(zoneIdChile).minusMonths(2).with(lastDayOfMonth());
        String fechaCotizaciones = localDate2.format(DateTimeFormatter.ofPattern("MMMM",
                Locale.forLanguageTag("es-ES"))).toLowerCase()
                + " " + localDate2.format(DateTimeFormatter.ofPattern("yyyy"));
        String periodo = localDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        log.info("periodo {}", periodo); //periodo 2023-03
        */




        String test = "Control cambio Gestión de Solicitud Registro de Rechazos y Creación de Nuevas Solicitudes 18-10.pdf";
        log.info("test {}",test);
        log.info("test {}",test.toLowerCase());
        log.info("test {}",test.toUpperCase());
        //test = Normalizer.normalize(test, Normalizer.Form.NFD);
        //log.info("test normalizer {}",test);
        test = test.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        log.info("test  replace all {}",test);


        //SIN EMBARGO, tener ojo con estos casos y probar que esto realmente funciona en nuestros ambientes

        log.info("one to one 2, no checks for null id, let JPA handle it");
        log.info("request: {}",request);
        User userInsert = User.builder()
                .id(request.getUserDto().getId())
                .descripcion(request.getUserDto().getDescripcion())
                .build();
        Address addressInsert = Address.builder()
                .id(request.getAddressDto().getId())
                .descripcion(request.getAddressDto().getDescripcion())
                .build();
        userInsert.setAddress(addressInsert);
        addressInsert.setUser(userInsert);

        //JPA parece poder manejar bastante bien el tema, pero siempre tener cuidado, es mejor validar uno mismo
        // para cubrir los casos esperados, ya que lo que JPA hace internamente es caja negra para nosotros

        User savedUser = userRepository.save(userInsert);//opcion 1, guardar desde user
        log.info("saved user: {}", savedUser);
        log.info("saved address: {}", savedUser.getAddress());
    }

    @Override
    public void manyToMany1(ManyToManyRequest request) {
        //esta relacion de tabla intermedia solo esta relacionando las dos tablas, no tiene
        //mas informacion que eso, asi que dejamos que JPA la maneje internamente

        log.info("many to many 1, no checks for null id, let JPA handle it");
        log.info("request: {}",request);

        //como recibimos listas, hay que recorrerlas.
        //notar que las entidades no reciven listas, si no sets
        //para este ejemplo no se probo que pasa al agregarlo al set
        // si en la lista de entrada biene algo repetido

        //lista cursos
        Set<Course> courseSet = new HashSet<>();
        for(CourseDto courseDto: request.getCourseDto()) {
            Course course = Course.builder()
                    .id(courseDto.getId())
                    .descripcion(courseDto.getDescripcion())
                    .build();
            courseSet.add(course);
        }

        //lista estudiantes
        Set<Student> studentSet = new HashSet<>();
        for(StudentDto studentDto: request.getStudentDto()) {
            Student student = Student.builder()
                    .id(studentDto.getId())
                    .descripcion(studentDto.getDescripcion())
                    .likedCourses(courseSet)
                    .build();
            studentSet.add(student);
        }

        //parte del problema de aceptar 2 listas desde el front es como las relacionamos
        //es mas facil si el front nos envia, por ejemplo, 1 solo estudiante
        // con la lista de cursos que le gustaron (y mas normal), eso se hara en otro endpoint

        //aqui hicimos que todos los estudiantes que recibimos
        // queden relacionados con todos los cursos que recibimos
        //esto, obviamente, en la mayoria de los casos no estaria bien
        // pero la idea de estos ejemplos es mostrar como hacer algo

        List<Student> studentSavedList = studentRepository.save(studentSet);
        log.info("studentSavedList: {}", studentSavedList);

        Set<Student> getAllStudents = studentRepository.allStudentsWithCourses();

        for (Student student : getAllStudents) {
            log.info("courses for student id {}: {}", student.getId(), student.getLikedCourses());
        }

        // todos lso estudiantes que se reciben quedan relacionados con todos los cursos que se reciben
        // inserta los X estudiantes y los N cursos
        // y deja Z relaciones, X por cada estudiante, relancionandolo a los N cursos

    }

    @Override
    public void manyToMany2(ManyToManyRequest request) {
        // entidad de tabla intermedia, muchos a uno para Student, muchos a uno para Course
    }


}
