package com.example.demo.repositorio;

import com.example.demo.entidad.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

}
