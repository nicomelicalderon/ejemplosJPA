package com.example.demo.controler;

import com.example.demo.dto.ManyToManyRequest;
import com.example.demo.dto.OneToOneRequest;
import com.example.demo.servicio.Servicio;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/controller")
public class Controller {

    @Autowired
    private Servicio servicio;

    @PostMapping(
            path = "/one-to-one",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiOperation(value="endpoint de operaciones uno a uno")
    public void oneToOne(@RequestBody OneToOneRequest request) {
        servicio.oneToOne2(request);
    }

    @PostMapping(
            path = "/many-to-many-1",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiOperation(value="endpoint de operaciones muchos a muchos, tabla intermedia solo tiene las relaciones")
    public void manyToMany1(@RequestBody ManyToManyRequest request) {
        servicio.manyToMany1(request);
    }

    @PostMapping(
            path = "/many-to-many-2",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiOperation(value="endpoint de operaciones muchos a muchos, tabla intermedia manual")
    public void manyToMany2(@RequestBody ManyToManyRequest request) {
        servicio.manyToMany2(request);
    }
}
