package com.example.demo.repositorio;

import com.example.demo.entidad.Address;
import com.example.demo.entidad.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Set;

public interface StudentRepository extends JpaRepository<Student, Long> {

    @Query(value = "SELECT s from Student s " +
            " JOIN FETCH s.likedCourses lc ")
    Set<Student> allStudentsWithCourses();
}
