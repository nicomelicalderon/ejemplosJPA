package com.example.demo.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ManyToManyRequest {
    private List<StudentDto> studentDto;
    private List<CourseDto> courseDto;
}
