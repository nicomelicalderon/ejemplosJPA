package com.example.demo.entidad;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "user")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //si el nombre de la columna es igual al nombre del campo, no se necesita
    //@Column(name = "descripcion")
    String descripcion;


    // https://www.baeldung.com/jpa-one-to-one
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
    private Address address;

    @Override
    public String toString() {
        return "User: {" +
                "id:'" + id + '\'' +
                ", descripcion:'" + descripcion + '\'' +
                ", address id:'" + address.getId() + '\'' +
                '}';
    }
}
