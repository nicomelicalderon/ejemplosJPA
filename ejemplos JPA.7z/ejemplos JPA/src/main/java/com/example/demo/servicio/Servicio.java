package com.example.demo.servicio;


import com.example.demo.dto.ManyToManyRequest;
import com.example.demo.dto.OneToOneRequest;

public interface Servicio {

    void oneToOne(OneToOneRequest request);

    void oneToOne2(OneToOneRequest request);

    void manyToMany1(ManyToManyRequest request);

    void manyToMany2(ManyToManyRequest request);
}
