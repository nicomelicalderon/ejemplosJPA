package com.example.demo.entidad;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "student")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    //si el nombre de la columna es igual al nombre del campo, no se necesita
    //@Column(name = "descripcion")
    String descripcion;

    /*
    https://www.baeldung.com/jpa-many-to-many
    We provide the name of the join table (course_like) as well as the foreign keys with the
    @JoinColumn annotations. The joinColumn attribute will connect to the owner side of the
    relationship, and the inverseJoinColumn to the other side
     */
    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinTable(
            name = "course_like",
            joinColumns = @JoinColumn(name = "student_id"),
            inverseJoinColumns = @JoinColumn(name = "course_id"))
    Set<Course> likedCourses;

    //para evitar que al logear relaciones en BD de errores recursivos, se puede hacer
    // override al to string y no imprimir el objeto directo de la relacion
    @Override
    public String toString() {
        return "\"Student\": {" +
                "\"id\":\"" + id + "\"," +
                "\"descripcion\":\"" + descripcion + "\"," +
                "\"likedCourses.size()\":\"" + likedCourses.size() + "\"" +
                "}";
    }
}