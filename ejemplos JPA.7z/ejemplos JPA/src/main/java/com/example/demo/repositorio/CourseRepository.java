package com.example.demo.repositorio;

import com.example.demo.entidad.Course;
import com.example.demo.entidad.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {

}
