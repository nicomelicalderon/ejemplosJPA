/*INSERT INTO public.para_evitar_error (id) VALUES(1);*/

/* si se quieren hacer inserts automaticos a las tablas de schema.sql, se pueden hacer aqui,
   leer instrucciones en archivo schema.sql
 */