/* esta tabla solo existe para que no falle al iniciar si es qye en application.properties
   no se encuentra comentada la linea "spring.jpa.defer-datasource-initialization=true"
   cuando eso esta comentado, schema.sql tiene que tener al menos 1 tabla en sql
   */
/*
CREATE TABLE public.para_evitar_error (
                             id bigserial NOT NULL,
                             CONSTRAINT para_evitar_error_pkey PRIMARY KEY (id)
);
*/
/*
CREATE TABLE public.user (
                                        id bigserial NOT NULL,
                                        descripcion varchar(255) NULL,
                                        address_id int8 NULL,
                                        CONSTRAINT user_pkey PRIMARY KEY (id)
);

CREATE TABLE public.address (
                             id bigserial NOT NULL,
                             descripcion varchar(255) NULL,
                             user_id int8 NULL,
                             CONSTRAINT address_pkey PRIMARY KEY (id)
);

-- public.user foreign keys
ALTER TABLE public.user ADD CONSTRAINT fk5p9yuloghr3lruefl996itm35
    FOREIGN KEY (address_id) REFERENCES public.address(id);

-- public.address foreign keys
ALTER TABLE public.address ADD CONSTRAINT fk5p9yuloghr3lruefl996itm36
    FOREIGN KEY (user_id) REFERENCES public.user(id);

CREATE SEQUENCE public.user_id_seq
    INCREMENT BY 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    START 1
	CACHE 1
	NO CYCLE;

CREATE SEQUENCE public.address_id_seq
    INCREMENT BY 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    START 1
	CACHE 1
	NO CYCLE;
*/

/*
  en application.properties se encuentra comentada la linea
  "spring.jpa.defer-datasource-initialization=true", esto creo que permite que hibernate levante la base
  de datos en memoria, pero el necesita tener al menos una tabla escrita en sql en este archivo.
  no estoy seguro si necesita minimo un insert en data.sql
  PERO, cuando en application.properties tenemos esto:
    spring.jpa.hibernate.ddl-auto=update
    #spring.jpa.defer-datasource-initialization=true

  jpa se encarga. si dse descomenta spring.jpa.defer-datasource-initialization=true dara error
  si este archivo no tiene al menos una tabla
  (se puede usar la de linea 6 si no les importa la tabla en si)
 */