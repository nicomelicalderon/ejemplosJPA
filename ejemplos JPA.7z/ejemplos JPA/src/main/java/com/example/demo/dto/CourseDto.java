package com.example.demo.dto;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CourseDto {
    private Long id;
    private String descripcion;
    private Long studentId;
}
