package com.example.demo.entidad;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "address")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //si el nombre de la columna es igual al nombre del campo, no se necesita
    //@Column(name = "descripcion")
    String descripcion;

    //https://www.baeldung.com/jpa-one-to-one
    @OneToOne(mappedBy = "address", fetch = FetchType.LAZY)
    private User user;

    @Override
    public String toString() {
        return "Address: {" +
                "id:'" + id + '\'' +
                ", descripcion:'" + descripcion + '\'' +
                ", user id:'" + user.getId() + '\'' +
                '}';
    }

}