package com.example.demo.entidad;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "course2")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Course2 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    //si el nombre de la columna es igual al nombre del campo, no se necesita
    //@Column(name = "descripcion")
    String descripcion;


    //https://www.baeldung.com/jpa-many-to-many
    //@ManyToMany(mappedBy = "likedCourses",fetch = FetchType.LAZY)
    //Set<Student> likes;

    //para evitar que al logear relaciones en BD de errores recursivos, se puede hacer
    // override al to string y no imprimir el objeto directo de la relacion
    @Override
    public String toString() {
        return "\"Course2:\" {" +
                "\"id\":\"" + id + ",\"" +
                "\"descripcion\":\"" + descripcion + ",\"" +
                //"\"getLikes().size()\":\"" + getLikes().size() + "\"" +
                "}";
    }
}
